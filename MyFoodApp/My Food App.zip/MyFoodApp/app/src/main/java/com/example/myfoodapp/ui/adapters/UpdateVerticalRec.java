package com.example.myfoodapp.ui.adapters;

import com.example.myfoodapp.ui.home.HomeVerModel;

import java.util.ArrayList;

public interface UpdateVerticalRec {
    public void callBack(int position, ArrayList<HomeVerModel> list);
}
